/**
 * This package includes user classes,
 * It includes the following class:
 * <br>
 * {@link gr.aueb.cf.ch13.user.User}<br>
 */
package gr.aueb.cf.ch13.user;
