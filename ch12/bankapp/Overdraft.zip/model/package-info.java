/**
 * This package includes model classes,
 * it includes the following classes:
 * <br>
 * {@link gr.aueb.cf.ch12.bankapp.model.OverdraftAccount}<br>
 * {@link gr.aueb.cf.ch12.bankapp.model.JointAccount}
 *
 * @author Manos
 */
package gr.aueb.cf.ch12.bankapp.model;
